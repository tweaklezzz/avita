const posts = [
    {
        title: "GTX 1060ti новая",
        img: "assets/posts/4.webp",
        seller: {
            name: "Олег Николаевич ИП",
            img: "",
            registeredAt: 2012
        },
        description: "lorem",
        price: "10 000",
        city: "msk",
        category: "gpu"
    },
    {
        title: "RTX 3060 после майнинга",
        img: "assets/posts/1.webp",
        seller: {
            name: "Mining Store",
            img: "",
            registeredAt: 2012
        },
        description: "lorem",
        price: "12 000",
        city: "spb",
        category: "gpu"
    },
    {
        title: "PS5 - На запчасти",
        img: "assets/posts/3.webp",
        seller: {
            name: "Михан",
            img: "",
            registeredAt: 2012
        },
        description: "lorem",
        price: "4 000",
        city: "msk",
        category: "console"
    },
    {
        title: "RTX 2060 - БУ",
        img: "assets/posts/5.webp",
        seller: {
            name: "Вася",
            img: "",
            registeredAt: 2012
        },
        description: "lorem",
        price: "4 000",
        city: "msk",
        category: "gpu"
    },
    {
        title: "Core i5 7400",
        img: "assets/posts/2.webp",
        seller: {
            name: "Вася",
            img: "",
            registeredAt: 2012
        },
        description: "lorem",
        price: "2 500",
        city: "spb",
        category: "cpu"
    },
]

let currentPosts = [...posts]
let filters = {}

const search = document.querySelector('.search')
const listing = document.querySelector('.listing')
const categoryFilter = document.querySelector('#category')
const cityFilter = document.querySelector('#city')
const popup = document.querySelector('.popup-wrapper')
const popupInner = document.querySelector('.popup')

function renderPosts(posts){
    listing.innerHTML = ""

    for(let post of posts){
        const template = `
            <a class="post" href="#">
                <div class="post-img">
                    <img src="${post?.img}" alt="">
                </div>
                <div class="post-title">
                    <p>${post?.title}</p>
                </div>
                <div class="post-data">
                    <p class="post-seller">${post?.seller?.name}</p>
                    <p class="post-button">${post?.price}</p>
                </div>
            </a>
        `

        listing.innerHTML += template
    }
}

search.addEventListener('input', (e) => {
//     const newPosts = posts.filter(post => {
//         return post.title.toLowerCase().includes(e.target.value.toLowerCase())
//     })
//     renderPosts(newPosts)
        filters.title = e.target.value
        renderFiltered()
})

// categoryFilter.addEventListener('change', (e) => filterByCategory(posts, e.target.value))
// function filterByCategory(posts, category){
//     currentPosts = posts.filter(post => {
//         return post.category == category
//     })
//     renderPosts(currentPosts)
// }

categoryFilter.addEventListener('change', (e) => {
    filters.category = e.target.value
    renderFiltered()
})
cityFilter.addEventListener('change', (e) => {
    filters.city = e.target.value
    renderFiltered()
})
// cityFilter.addEventListener('change', (e) => filterPostsBy(currentPosts, 'city', e.target.value))

function renderFiltered(){
    currentPosts = [...posts]
    for(let filter of Object.keys(filters)){
        currentPosts = filterPostsBy(currentPosts, filter, filters[filter])
    }
    renderPosts(currentPosts)
}

function filterPostsBy(filteringPosts, filterBy, value){
    
    if (value === ""){
        return filteringPosts
    }
    if(filterBy == "title"){
        return filteringPosts.filter(post => {
            return post.title.toLowerCase().includes(value.toLowerCase())
        })
        // return post.title.toLowerCase().includes(e.target.value.toLowerCase())
    }else{
        return filteringPosts.filter(post => {
            return post[filterBy] == value
        })
    }
}

function showPopup(){
    popup.classList.toggle("popup-shown")
}

popup.addEventListener('click', (e) => {
    if(e.target == popup){
        showPopup()
        console.log(e)
    }
})

renderPosts(posts)